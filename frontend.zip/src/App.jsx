import { useState, useRef, useEffect, useCallback } from "react";

const API = "http://localhost:8000";

async function api(path, opts = {}, token = null) {
  const headers = { "Content-Type": "application/json", ...(opts.headers || {}) };
  if (token) headers["Authorization"] = `Bearer ${token}`;
  const res = await fetch(`${API}${path}`, { ...opts, headers });
  const data = await res.json();
  if (!res.ok) throw new Error(data.detail || "Request failed");
  return data;
}

function Markdown({ src }) {
  const html = src
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/^#{3} (.+)$/gm, "<h3>$1</h3>")
    .replace(/^#{2} (.+)$/gm, "<h2>$1</h2>")
    .replace(/^# (.+)$/gm, "<h1>$1</h1>")
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/\*(.+?)\*/g, "<em>$1</em>")
    .replace(/`([^`]+)`/g, "<code>$1</code>")
    .replace(/^---+$/gm, "<hr/>")
    .replace(/^\| (.+) \|$/gm, (_, row) =>
      `<tr>${row.split(" | ").map(c => `<td>${c}</td>`).join("")}</tr>`
    )
    .replace(/(<tr>.*<\/tr>\n?)+/gs, m => `<table>${m}</table>`)
    .replace(/^\s*[-*] (.+)$/gm, "<li>$1</li>")
    .replace(/(<li>.*<\/li>\n?)+/gs, m => `<ul>${m}</ul>`)
    .replace(/^\d+\. (.+)$/gm, "<li>$1</li>")
    .replace(/\n\n/g, "<br/><br/>")
    .replace(/\n/g, "<br/>");
  return <div className="markdown" dangerouslySetInnerHTML={{ __html: html }} />;
}

const AGENT_META = {
  summary: { icon: "📋", label: "Summary" },
  explain: { icon: "💡", label: "Explain" },
  compare: { icon: "⚖️", label: "Compare" },
  quiz: { icon: "🎯", label: "Quiz" },
  citation: { icon: "📌", label: "Citation" },
  methodology: { icon: "🔬", label: "Methodology" },
  financial_summary: { icon: "📈", label: "Financial" },
  kpi: { icon: "📊", label: "KPI" },
  trend: { icon: "📉", label: "Trend" },
  risk: { icon: "⚠️", label: "Risk" },
  investor: { icon: "💼", label: "Investor" },
  financial_compare: { icon: "🔀", label: "Fin Compare" },
  balance_sheet: { icon: "🏦", label: "Balance Sheet" },
  multi: { icon: "🔗", label: "Multi-Agent" },
};

function AgentBadge({ type }) {
  const m = AGENT_META[type] || { icon: "🤖", label: type };
  return <span className="agent-badge">{m.icon} {m.label}</span>;
}

function TypingDots() {
  return (
    <div className="typing-dots">
      <span /><span /><span />
    </div>
  );
}

export default function App() {
  const [token, setToken] = useState(() => localStorage.getItem("askpdf_token") || "");
  const [username, setUsername] = useState(() => localStorage.getItem("askpdf_user") || "");
  const [authMode, setAuthMode] = useState("login");
  const [authUser, setAuthUser] = useState("");
  const [authPass, setAuthPass] = useState("");
  const [authErr, setAuthErr] = useState("");
  const [authLoading, setAuthLoading] = useState(false);

  // pdfReady is restored from /pdf-status on mount so page refresh doesn't lose it
  const [pdfReady, setPdfReady] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [uploadErr, setUploadErr] = useState("");
  // fileName persisted in localStorage so it survives refresh
  const [fileName, setFileName] = useState(() => localStorage.getItem("askpdf_file") || "");

  const [messages, setMessages] = useState([]);
  const [question, setQuestion] = useState("");
  const [thinking, setThinking] = useState(false);

  const bottomRef = useRef(null);
  const fileRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, thinking]);

  // ── Restore pdf-ready state after page refresh ─────────────────────────────
  useEffect(() => {
    if (!token) return;
    api("/pdf-status", {}, token)
      .then(data => {
        if (data.ready) {
          setPdfReady(true);
        } else {
          // Backend restarted — clear stale filename
          localStorage.removeItem("askpdf_file");
          setFileName("");
          setPdfReady(false);
        }
      })
      .catch(() => {});
  }, [token]);

  // ── Auth ───────────────────────────────────────────────────────────────────
  const handleAuth = async (e) => {
    e.preventDefault();
    setAuthErr("");
    setAuthLoading(true);
    try {
      if (authMode === "register") {
        await api("/auth/register", {
          method: "POST",
          body: JSON.stringify({ username: authUser, password: authPass }),
        });
        setAuthMode("login");
        setAuthErr("Account created! Please sign in.");
      } else {
        const data = await api("/auth/login", {
          method: "POST",
          body: JSON.stringify({ username: authUser, password: authPass }),
        });
        localStorage.setItem("askpdf_token", data.token);
        localStorage.setItem("askpdf_user", data.username);
        setToken(data.token);
        setUsername(data.username);
      }
    } catch (err) {
      setAuthErr(err.message);
    } finally {
      setAuthLoading(false);
    }
  };

  const logout = () => {
    localStorage.clear();
    setToken(""); setUsername(""); setPdfReady(false);
    setMessages([]); setFileName("");
  };

  // ── PDF upload ─────────────────────────────────────────────────────────────
  const handleFile = async (file) => {
    if (!file) return;
    setUploadErr("");
    setUploading(true);
    setFileName(file.name);
    localStorage.setItem("askpdf_file", file.name);
    const form = new FormData();
    form.append("file", file);
    try {
      const res = await fetch(`${API}/upload`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: form,
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail);
      setPdfReady(true);
      setMessages([]);
    } catch (err) {
      setUploadErr(err.message);
      setFileName("");
      localStorage.removeItem("askpdf_file");
    } finally {
      setUploading(false);
    }
  };

  const onDrop = useCallback((e) => {
    e.preventDefault();
    const f = e.dataTransfer.files[0];
    if (f) handleFile(f);
  }, [token]);

  // ── Chat ───────────────────────────────────────────────────────────────────
  const sendMessage = async (e) => {
    e.preventDefault();
    if (!question.trim() || thinking) return;
    const q = question.trim();
    setQuestion("");
    setMessages(m => [...m, { role: "user", content: q }]);
    setThinking(true);
    try {
      const data = await api("/chat", {
        method: "POST",
        body: JSON.stringify({ question: q }),
      }, token);
      setMessages(m => [...m, {
        role: "assistant",
        content: data.answer,
        agent: data.agent_type,
        meta: `retrieved in ${data.retrieval_ms}ms · generated in ${data.llm_ms}ms`,
      }]);
    } catch (err) {
      setMessages(m => [...m, { role: "assistant", content: `⚠️ ${err.message}`, agent: "" }]);
    } finally {
      setThinking(false);
    }
  };

  const newChat = async () => {
    try { await api("/new-chat", { method: "POST" }, token); } catch (_) {}
    setPdfReady(false);
    setMessages([]);
    setFileName("");
    localStorage.removeItem("askpdf_file");
  };

  // ── AUTH SCREEN ────────────────────────────────────────────────────────────
  if (!token) return (
    <>
      <style>{CSS}</style>
      <div className="auth-screen">
        <div className="auth-card">
          <div className="auth-logo">📄</div>
          <h1 className="auth-title">AskPDF</h1>
          <p className="auth-sub">Chat with your documents</p>
          <div className="auth-tabs">
            <button className={authMode === "login" ? "active" : ""} onClick={() => { setAuthMode("login"); setAuthErr(""); }}>Sign In</button>
            <button className={authMode === "register" ? "active" : ""} onClick={() => { setAuthMode("register"); setAuthErr(""); }}>Sign Up</button>
          </div>
          <form onSubmit={handleAuth} className="auth-form">
            <input placeholder="Username" value={authUser} onChange={e => setAuthUser(e.target.value)} autoFocus required />
            <input type="password" placeholder="Password" value={authPass} onChange={e => setAuthPass(e.target.value)} required />
            {authErr && <p className={`auth-msg ${authErr.includes("created") ? "ok" : "err"}`}>{authErr}</p>}
            <button type="submit" className="btn-primary" disabled={authLoading}>
              {authLoading ? "…" : authMode === "login" ? "Sign In" : "Create Account"}
            </button>
          </form>
        </div>
      </div>
    </>
  );

  // ── MAIN APP ───────────────────────────────────────────────────────────────
  return (
    <>
      <style>{CSS}</style>
      <div className="layout">

        {/* Sidebar */}
        <aside className="sidebar">
          <div className="sidebar-logo">📄 AskPDF</div>

          <div
            className={`drop-zone ${uploading ? "loading" : ""} ${pdfReady ? "ready" : ""}`}
            onDragOver={e => e.preventDefault()}
            onDrop={onDrop}
            onClick={() => !uploading && fileRef.current?.click()}
          >
            <input
              ref={fileRef}
              type="file"
              accept=".pdf"
              style={{ display: "none" }}
              onChange={e => handleFile(e.target.files[0])}
            />
            {uploading ? (
              <><div className="spin" /><span>Processing…</span></>
            ) : pdfReady ? (
              <>
                <span className="drop-icon">✅</span>
                <span className="drop-name">{fileName}</span>
                <span className="drop-hint">Click to replace PDF</span>
              </>
            ) : (
              <><span className="drop-icon">📂</span><span>Drop PDF here</span><span className="drop-hint">or click to browse</span></>
            )}
          </div>
          {uploadErr && <p className="upload-err">{uploadErr}</p>}

          {/* PDF ready indicator */}
          {pdfReady && (
            <div className="pdf-status-bar">
              <span className="pdf-status-dot" />
              PDF loaded — ask away!
            </div>
          )}

          <div className="pill-section">
            <p className="pill-label">Capabilities</p>
            <div className="pill-grid">
              {Object.values(AGENT_META).slice(0, 8).map(a => (
                <span key={a.label} className="pill">{a.icon} {a.label}</span>
              ))}
            </div>
          </div>

          <div className="sidebar-spacer" />

          <button className="btn-ghost" onClick={newChat}>➕ New Chat</button>
          <div className="user-row">
            <span className="user-name">👤 {username}</span>
            <button className="btn-ghost small" onClick={logout}>Logout</button>
          </div>
        </aside>

        {/* Chat area */}
        <main className="chat-area">
          {messages.length === 0 && !thinking && (
            <div className="empty-state">
              <div className="empty-icon">💬</div>
              <h2>{pdfReady ? `Ask anything about "${fileName}"` : "Upload a PDF to get started"}</h2>
              {pdfReady && (
                <div className="suggestions">
                  {["Summarize this document", "What is the methodology?", "Extract key KPIs"].map(s => (
                    <button key={s} className="suggestion" onClick={() => setQuestion(s)}>{s}</button>
                  ))}
                </div>
              )}
            </div>
          )}

          <div className="messages">
            {messages.map((m, i) => (
              <div key={i} className={`msg msg-${m.role}`}>
                {m.role === "assistant" && (
                  <div className="msg-header">
                    <span className="msg-icon">🤖</span>
                    {m.agent && <AgentBadge type={m.agent} />}
                  </div>
                )}
                {m.role === "user" ? (
                  <div className="bubble-user">{m.content}</div>
                ) : (
                  <div className="bubble-ai">
                    <Markdown src={m.content} />
                    {m.meta && <p className="msg-meta">{m.meta}</p>}
                  </div>
                )}
              </div>
            ))}

            {thinking && (
              <div className="msg msg-assistant">
                <div className="msg-header"><span className="msg-icon">🤖</span></div>
                <div className="bubble-ai"><TypingDots /></div>
              </div>
            )}
            <div ref={bottomRef} />
          </div>

          <form className="input-bar" onSubmit={sendMessage}>
            <input
              className="chat-input"
              placeholder={pdfReady ? "Ask anything about your PDF…" : "Upload a PDF first…"}
              value={question}
              onChange={e => setQuestion(e.target.value)}
              disabled={!pdfReady || thinking}
            />
            <button type="submit" className="send-btn" disabled={!pdfReady || thinking || !question.trim()}>
              {thinking ? <div className="spin small" /> : "↑"}
            </button>
          </form>
        </main>
      </div>
    </>
  );
}

const CSS = `
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
  --bg: #0e0f14;
  --surface: #16181f;
  --surface2: #1e2029;
  --border: rgba(255,255,255,0.07);
  --accent: #7c6af7;
  --accent2: #5eead4;
  --text: #e8e9f0;
  --text2: #8b8fa8;
  --user-bg: linear-gradient(135deg, #7c6af7, #5eead4);
  --radius: 14px;
  --font-head: 'Syne', sans-serif;
  --font-body: 'DM Sans', sans-serif;
}

body { background: var(--bg); color: var(--text); font-family: var(--font-body); }

.auth-screen {
  min-height: 100vh;
  display: flex; align-items: center; justify-content: center;
  background: radial-gradient(ellipse at 30% 20%, rgba(124,106,247,0.15) 0%, transparent 60%),
              radial-gradient(ellipse at 70% 80%, rgba(94,234,212,0.10) 0%, transparent 60%),
              var(--bg);
}
.auth-card {
  width: 100%; max-width: 400px;
  background: var(--surface); border: 1px solid var(--border);
  border-radius: 24px; padding: 2.5rem;
  display: flex; flex-direction: column; gap: 1rem;
}
.auth-logo { font-size: 2.5rem; text-align: center; }
.auth-title { font-family: var(--font-head); font-size: 2rem; font-weight: 800; text-align: center; background: linear-gradient(135deg,#7c6af7,#5eead4); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.auth-sub { text-align: center; color: var(--text2); font-size: .9rem; }
.auth-tabs { display: flex; background: var(--surface2); border-radius: 10px; padding: 3px; gap: 3px; }
.auth-tabs button { flex: 1; padding: .5rem; border: none; background: transparent; color: var(--text2); border-radius: 8px; cursor: pointer; font-family: var(--font-body); transition: .2s; }
.auth-tabs button.active { background: var(--accent); color: white; }
.auth-form { display: flex; flex-direction: column; gap: .75rem; }
.auth-form input { background: var(--surface2); border: 1px solid var(--border); border-radius: 10px; padding: .75rem 1rem; color: var(--text); font-family: var(--font-body); font-size: 1rem; outline: none; transition: border .2s; }
.auth-form input:focus { border-color: var(--accent); }
.auth-msg { font-size: .85rem; text-align: center; }
.auth-msg.ok { color: var(--accent2); }
.auth-msg.err { color: #f87171; }
.btn-primary { background: linear-gradient(135deg, var(--accent), #5eead4); color: white; border: none; border-radius: 10px; padding: .8rem; font-weight: 600; font-size: 1rem; cursor: pointer; transition: opacity .2s, transform .15s; font-family: var(--font-body); }
.btn-primary:hover { opacity: .9; transform: translateY(-1px); }
.btn-primary:disabled { opacity: .5; cursor: not-allowed; transform: none; }

.layout { display: flex; height: 100vh; overflow: hidden; }

.sidebar { width: 260px; flex-shrink: 0; background: var(--surface); border-right: 1px solid var(--border); display: flex; flex-direction: column; padding: 1.25rem 1rem; gap: .75rem; overflow-y: auto; }
.sidebar-logo { font-family: var(--font-head); font-size: 1.3rem; font-weight: 800; color: var(--accent); padding: .25rem .5rem; }

.drop-zone { border: 2px dashed var(--border); border-radius: var(--radius); padding: 1.25rem 1rem; display: flex; flex-direction: column; align-items: center; gap: .4rem; cursor: pointer; transition: border-color .2s, background .2s; text-align: center; font-size: .85rem; color: var(--text2); }
.drop-zone:hover { border-color: var(--accent); background: rgba(124,106,247,0.05); }
.drop-zone.ready { border-color: var(--accent2); border-style: solid; }
.drop-zone.loading { cursor: wait; }
.drop-icon { font-size: 1.6rem; }
.drop-name { font-size: .8rem; color: var(--accent2); word-break: break-all; }
.drop-hint { font-size: .75rem; color: var(--text2); }
.upload-err { font-size: .8rem; color: #f87171; text-align: center; }

.pdf-status-bar { display: flex; align-items: center; gap: .5rem; font-size: .78rem; color: var(--accent2); padding: .3rem .5rem; background: rgba(94,234,212,0.07); border-radius: 8px; border: 1px solid rgba(94,234,212,0.15); }
.pdf-status-dot { width: 7px; height: 7px; border-radius: 50%; background: var(--accent2); flex-shrink: 0; box-shadow: 0 0 6px var(--accent2); animation: glow 2s ease-in-out infinite; }
@keyframes glow { 0%,100% { opacity: 1; } 50% { opacity: .4; } }

.pill-section { margin-top: .25rem; }
.pill-label { font-size: .7rem; font-weight: 600; color: var(--text2); text-transform: uppercase; letter-spacing: .08em; margin-bottom: .5rem; padding: 0 .25rem; }
.pill-grid { display: flex; flex-wrap: wrap; gap: .35rem; }
.pill { font-size: .7rem; padding: .3rem .6rem; border-radius: 999px; background: rgba(124,106,247,0.12); color: var(--accent); border: 1px solid rgba(124,106,247,0.2); }

.sidebar-spacer { flex: 1; }

.btn-ghost { background: transparent; border: 1px solid var(--border); border-radius: 10px; color: var(--text2); padding: .6rem .75rem; cursor: pointer; font-size: .85rem; transition: .2s; text-align: left; font-family: var(--font-body); }
.btn-ghost:hover { border-color: var(--accent); color: var(--accent); }
.btn-ghost.small { padding: .35rem .6rem; font-size: .78rem; }

.user-row { display: flex; align-items: center; gap: .5rem; }
.user-name { font-size: .82rem; color: var(--text2); flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }

.chat-area { flex: 1; display: flex; flex-direction: column; background: var(--bg); overflow: hidden; position: relative; }

.empty-state { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 1rem; padding: 2rem; text-align: center; }
.empty-icon { font-size: 3rem; }
.empty-state h2 { font-family: var(--font-head); font-size: 1.4rem; color: var(--text2); }
.suggestions { display: flex; flex-direction: column; gap: .5rem; margin-top: .5rem; }
.suggestion { background: var(--surface); border: 1px solid var(--border); border-radius: 10px; color: var(--text2); padding: .6rem 1.2rem; cursor: pointer; font-family: var(--font-body); font-size: .9rem; transition: .2s; }
.suggestion:hover { border-color: var(--accent); color: var(--text); }

.messages { flex: 1; overflow-y: auto; padding: 1.5rem 1.5rem 0; display: flex; flex-direction: column; gap: 1.25rem; scrollbar-width: thin; scrollbar-color: var(--surface2) transparent; }

.msg { display: flex; flex-direction: column; gap: .4rem; }
.msg-user { align-items: flex-end; }
.msg-assistant { align-items: flex-start; }
.msg-header { display: flex; align-items: center; gap: .5rem; }
.msg-icon { font-size: 1rem; }
.agent-badge { font-size: .7rem; padding: .2rem .6rem; border-radius: 999px; background: rgba(94,234,212,0.12); color: var(--accent2); border: 1px solid rgba(94,234,212,0.2); }
.bubble-user { background: var(--user-bg); color: white; padding: .75rem 1rem; border-radius: 18px 18px 4px 18px; max-width: 70%; font-size: .95rem; line-height: 1.55; }
.bubble-ai { background: var(--surface); border: 1px solid var(--border); border-radius: 4px 18px 18px 18px; padding: 1rem 1.1rem; max-width: min(75%, 720px); font-size: .93rem; line-height: 1.65; }
.msg-meta { font-size: .72rem; color: var(--text2); margin-top: .6rem; }

.markdown h1 { font-family: var(--font-head); font-size: 1.2rem; margin: .75rem 0 .4rem; color: var(--accent2); }
.markdown h2 { font-family: var(--font-head); font-size: 1.05rem; margin: .6rem 0 .35rem; color: var(--text); }
.markdown h3 { font-size: .95rem; margin: .5rem 0 .3rem; color: var(--text); }
.markdown strong { color: var(--text); }
.markdown code { background: var(--surface2); padding: .1rem .35rem; border-radius: 5px; font-size: .85em; color: var(--accent2); }
.markdown hr { border: none; border-top: 1px solid var(--border); margin: .75rem 0; }
.markdown table { width: 100%; border-collapse: collapse; margin: .6rem 0; font-size: .88rem; }
.markdown td { padding: .5rem .7rem; border: 1px solid var(--border); }
.markdown tr:first-child td { background: rgba(124,106,247,0.12); color: var(--accent); font-weight: 600; }
.markdown ul { padding-left: 1.25rem; }
.markdown li { margin: .2rem 0; }

.input-bar { display: flex; align-items: center; gap: .75rem; padding: 1rem 1.5rem 1.25rem; background: linear-gradient(transparent, var(--bg) 30%); }
.chat-input { flex: 1; background: var(--surface); border: 1px solid var(--border); border-radius: 14px; color: var(--text); padding: .8rem 1.1rem; font-family: var(--font-body); font-size: .95rem; outline: none; transition: border .2s; }
.chat-input:focus { border-color: var(--accent); }
.chat-input:disabled { opacity: .5; cursor: not-allowed; }
.send-btn { width: 42px; height: 42px; background: linear-gradient(135deg, var(--accent), var(--accent2)); border: none; border-radius: 12px; color: white; font-size: 1.1rem; font-weight: 700; cursor: pointer; display: flex; align-items: center; justify-content: center; transition: opacity .2s, transform .15s; flex-shrink: 0; }
.send-btn:hover:not(:disabled) { opacity: .88; transform: translateY(-1px); }
.send-btn:disabled { opacity: .4; cursor: not-allowed; transform: none; }

.spin { width: 18px; height: 18px; border: 2px solid rgba(255,255,255,0.3); border-top-color: white; border-radius: 50%; animation: spin .7s linear infinite; }
.spin.small { width: 14px; height: 14px; }
@keyframes spin { to { transform: rotate(360deg); } }

.typing-dots { display: flex; gap: 5px; align-items: center; padding: .2rem 0; }
.typing-dots span { width: 7px; height: 7px; border-radius: 50%; background: var(--accent); opacity: .4; animation: pulse 1.2s ease-in-out infinite; }
.typing-dots span:nth-child(2) { animation-delay: .2s; }
.typing-dots span:nth-child(3) { animation-delay: .4s; }
@keyframes pulse { 0%,80%,100% { opacity:.2; transform:scale(.9); } 40% { opacity:1; transform:scale(1.15); } }
`;
