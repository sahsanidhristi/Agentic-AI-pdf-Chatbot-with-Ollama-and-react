import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      '/auth': 'http://localhost:8000',
      '/upload': 'http://localhost:8000',
      '/chat': 'http://localhost:8000',
      '/new-chat': 'http://localhost:8000',
      '/history': 'http://localhost:8000',
      '/pdf-status': 'http://localhost:8000',
    }
  }
})
