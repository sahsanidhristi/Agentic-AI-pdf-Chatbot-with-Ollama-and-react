VALID_AGENTS = {
    "summary",
    "explain",       # was "detail" — matches supervisor_node output
    "methodology",
    "compare",
    "quiz",
    "citation",
    "multi",
    "financial_summary",
    "financial_compare",
    "kpi",
    "trend",
    "risk",
    "investor",
    "balance_sheet",
}


def router(state):
    agent_type = state.get("agent_type", "summary")
    if agent_type in VALID_AGENTS:
        return agent_type
    return "summary"
