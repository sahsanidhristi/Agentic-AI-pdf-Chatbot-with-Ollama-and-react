from langgraph.graph import StateGraph, END

from graph.state import AgentState

from graph.nodes import (
    supervisor_node,
    summary_node,
    explain_node,
    methodology_node,
    compare_node,
    quiz_node,
    citation_node,
    multi_agent_node,
    financial_summary_node,
    kpi_node,
    trend_node,
    risk_node,
    investor_node,
    financial_compare_node,
    balance_sheet_node
)

from graph.router import router


def build_graph():

    workflow = StateGraph(AgentState)

    # NODES
    workflow.add_node(
        "supervisor",
        supervisor_node
    )

    workflow.add_node(
        "summary",
        summary_node
    )

    workflow.add_node(
        "explain",
        explain_node
    )

    workflow.add_node(
        "methodology",
        methodology_node
    )

    workflow.add_node(
        "compare",
        compare_node
    )

    workflow.add_node(
        "quiz",
        quiz_node
    )

    workflow.add_node(
        "citation",
        citation_node
    )

    workflow.add_node(
        "multi",
        multi_agent_node
    )

    workflow.add_node(
    "financial_summary",
    financial_summary_node
)

    workflow.add_node(
        "kpi",
        kpi_node
    )

    workflow.add_node(
        "trend",
        trend_node
    )

    workflow.add_node(
        "risk",
        risk_node
    )

    workflow.add_node(
        "investor",
        investor_node
    )


    workflow.add_node(
        "financial_compare",
        financial_compare_node
    )  
    workflow.add_node(
      "balance_sheet",
       balance_sheet_node
)

    # ENTRY
    workflow.set_entry_point(
        "supervisor"
    )

    # ROUTING
    workflow.add_conditional_edges(
        "supervisor",
        router,
        {
            "summary": "summary",
            "explain": "explain",
            "methodology": "methodology",
            "compare": "compare",
            "quiz": "quiz",
            "citation": "citation",
            "multi": "multi",
            "financial_summary": "financial_summary",
            "kpi": "kpi",
            "trend": "trend",
            "risk": "risk",
            "investor": "investor",
            "financial_compare": "financial_compare",
            "balance_sheet": "balance_sheet",
        }
    )

    # END
    workflow.add_edge("summary", END)

    workflow.add_edge("explain", END)

    workflow.add_edge("methodology", END)

    workflow.add_edge("compare", END)

    workflow.add_edge("quiz", END)

    workflow.add_edge("citation", END)

    workflow.add_edge("multi", END)
    workflow.add_edge("financial_summary", END)
    workflow.add_edge("kpi", END)
    workflow.add_edge("trend", END)
    workflow.add_edge("risk", END)
    workflow.add_edge("investor", END)
    workflow.add_edge("financial_compare", END)
    workflow.add_edge("balance_sheet", END)

    app = workflow.compile()

    return app