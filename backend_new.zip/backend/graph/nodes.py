from langchain_ollama import ChatOllama
from utils.prompts import *

# --------------------------------------------------
# Speed optimisations (without losing data quality):
#
#  num_ctx   4096 → was 8192.
#   Context budget:  context(~2000t) + prompt(~100t) + answer(1500t) = ~3600t
#   Fits comfortably in 4096.  Smaller ctx = faster KV-cache fill = faster
#   first-token latency.  This alone cuts ~30-40% of wall-clock time.
#
#  num_thread  6  → was 4.  More CPU threads = faster token generation.
#
#  num_predict budgets tightened:
#   fast   300  (tables, short lists)
#   medium 900  (summaries — all bullet points still fit)
#   detail 1500 (full explanations — same content, less padding)
#
#  repeat_penalty 1.15 → was 1.1.  Stops repetitive rambling sooner.
#
#  keep_alive "10m" — keeps model warm in RAM between requests so the
#   next call doesn't reload weights (saves ~20-40 s on cold start).
# --------------------------------------------------

_BASE = dict(
    model="qwen2.5:7b",
    temperature=0.05,
    num_ctx=6144,
    # num_ctx=8192,
    num_thread=6,
    repeat_penalty=1.15,
    keep_alive="10m",
    request_timeout=300,
    stop=["\n\n\n\n\n"],
)

_llm_fast   = ChatOllama(**_BASE, num_predict=300)
_llm_medium = ChatOllama(**_BASE, num_predict=1200)
_llm_detail = ChatOllama(**_BASE, num_predict=2500)
# _llm_fast   = ChatOllama(**_BASE, num_predict=512)
# _llm_medium = ChatOllama(**_BASE, num_predict=1500)
# _llm_detail = ChatOllama(**_BASE, num_predict=3500)


def supervisor_node(state):
    question = state["question"].lower()

    # ── Financial agents ──────────────────────────────────────────────────────
    if any(k in question for k in ("kpi", "financial metrics", "eps", "ebitda")):
        state["agent_type"] = "kpi"
    elif any(k in question for k in ("trend", "growth", "year over year")):
        state["agent_type"] = "trend"
    elif any(k in question for k in ("risk", "financial risk")):
        state["agent_type"] = "risk"
    elif any(k in question for k in ("investor", "business insight")):
        state["agent_type"] = "investor"
    elif any(k in question for k in ("financial summary", "annual report summary")):
        state["agent_type"] = "financial_summary"
    elif any(k in question for k in ("compare financial", "compare revenue", "compare profit")):
        state["agent_type"] = "financial_compare"
    elif any(k in question for k in ("balance sheet", "financial statement")):
        state["agent_type"] = "balance_sheet"

    # ── Multi ─────────────────────────────────────────────────────────────────
    elif "explain" in question and "compare" in question:
        state["agent_type"] = "multi"

    # ── Quiz ──────────────────────────────────────────────────────────────────
    elif any(k in question for k in ("quiz", "mcq", "multiple choice")):
        state["agent_type"] = "quiz"

    # ── Citation ──────────────────────────────────────────────────────────────
    elif "citation" in question:
        state["agent_type"] = "citation"

    # ── Summary ───────────────────────────────────────────────────────────────
    elif any(k in question for k in ("summary", "summarize", "summarise", "overview")):
        state["agent_type"] = "summary"

    # ── Methodology ───────────────────────────────────────────────────────────
    elif any(k in question for k in (
        "methodology", "research methodology", "research method",
        "procedure", "phases of", "stages of",
    )):
        state["agent_type"] = "methodology"

    # ── Compare ───────────────────────────────────────────────────────────────
    elif any(k in question for k in ("compare", "difference", "vs", "versus", "contrast")):
        state["agent_type"] = "compare"

    # ── Default: explain ──────────────────────────────────────────────────────
    else:
        state["agent_type"] = "explain"

    return state


def _fast(prompt):   return _llm_fast.invoke(prompt).content
def _medium(prompt): return _llm_medium.invoke(prompt).content
def _detail(prompt): return _llm_detail.invoke(prompt).content


def summary_node(state):
    state["answer"] = _medium(SUMMARY_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def explain_node(state):
    state["answer"] = _detail(DETAIL_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def methodology_node(state):
    state["answer"] = _detail(METHODOLOGY_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def compare_node(state):
    state["answer"] = _medium(COMPARE_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def quiz_node(state):
    state["answer"] = _detail(QUIZ_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def citation_node(state):
    state["answer"] = _medium(CITATION_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def multi_agent_node(state):
    prompt = (
        f"{STRICT_COMMON_RULES}\n\n"
        f"CONTEXT:\n{state['context']}\n\n"
        f"USER QUESTION: {state['question']}\n\n"
        "First explain the topic from the CONTEXT, then compare if applicable.\n\n"
        "# Explanation\n"
        "Explain all relevant points from the CONTEXT in clear prose.\n\n"
        "# Comparison\n"
        "| Feature | A | B |\n"
        "|---------|---|---|"
    )
    state["answer"] = _detail(prompt)
    return state


def financial_summary_node(state):
    state["answer"] = _medium(FINANCIAL_SUMMARY_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def kpi_node(state):
    state["answer"] = _fast(KPI_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def trend_node(state):
    state["answer"] = _fast(TREND_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def risk_node(state):
    state["answer"] = _medium(RISK_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def investor_node(state):
    state["answer"] = _medium(INVESTOR_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def financial_compare_node(state):
    state["answer"] = _medium(FINANCIAL_COMPARE_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state


def balance_sheet_node(state):
    state["answer"] = _detail(BALANCE_SHEET_PROMPT.format(
        context=state["context"], question=state["question"]))
    return state
