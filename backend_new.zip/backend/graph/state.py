from typing_extensions import TypedDict
from typing import List, Optional


class AgentState(TypedDict):

    # User question
    question: str

    # Retrieved context from vector DB
    context: str

    # Final generated answer
    answer: str

    # Selected agent type
    agent_type: str

    # Chat history
    chat_history: List

    # Citations / references
    citations: List[str]

    # Intermediate outputs from agents
    intermediate_outputs: List[str]

    # ===== Financial Analysis Support =====

    # Detected document type
    # Example: research_paper, financial_report, annual_report
    document_type: Optional[str]

    # Extracted financial metrics
    # Example:
    # {
    #   "revenue": "10B",
    #   "profit": "2B"
    # }
    financial_metrics: Optional[dict]

    # Financial year extracted
    # Example: "FY2024"
    financial_year: Optional[str]

    # Company name extracted
    company_name: Optional[str]

    # Risk level
    # Example: low, medium, high
    risk_level: Optional[str]

    # Trend insights
    trends: Optional[List[str]]

    # KPI insights
    kpis: Optional[List[str]]

    # Investor insights
    investor_summary: Optional[str]