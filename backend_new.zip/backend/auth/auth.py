# import sqlite3
# import bcrypt

# DB_NAME = "users.db"

# def create_users_table():

#     conn = sqlite3.connect(DB_NAME)
#     cursor = conn.cursor()

#     cursor.execute("""
#     CREATE TABLE IF NOT EXISTS users(
#         username TEXT PRIMARY KEY,
#         password BLOB
#     )
#     """)

#     conn.commit()
#     conn.close()

# def register_user(username, password):

#     conn = sqlite3.connect(DB_NAME)
#     cursor = conn.cursor()

#     hashed = bcrypt.hashpw(
#         password.encode(),
#         bcrypt.gensalt()
#     )

#     try:
#         cursor.execute(
#             "INSERT INTO users(username, password) VALUES (?, ?)",
#             (username, hashed)
#         )

#         conn.commit()
#         return True

#     except:
#         return False

# def login_user(username, password):

#     conn = sqlite3.connect(DB_NAME)
#     cursor = conn.cursor()

#     cursor.execute(
#         "SELECT password FROM users WHERE username=?",
#         (username,)
#     )

#     result = cursor.fetchone()

#     if result:

#         stored_password = result[0]

#         if bcrypt.checkpw(
#             password.encode(),
#             stored_password
#         ):
#             return True

#     return False



import sqlite3
import bcrypt

DB_NAME = "users.db"


def create_users_table():

    with sqlite3.connect(DB_NAME) as conn:

        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users(
            username TEXT PRIMARY KEY,
            password BLOB
        )
        """)

        conn.commit()


def register_user(username, password):

    hashed = bcrypt.hashpw(
        password.encode(),
        bcrypt.gensalt(rounds=10)
    )

    try:

        with sqlite3.connect(DB_NAME) as conn:

            cursor = conn.cursor()

            cursor.execute(
                """
                INSERT INTO users(username, password)
                VALUES (?, ?)
                """,
                (username, hashed)
            )

            conn.commit()

        return True

    except sqlite3.IntegrityError:
        return False


def login_user(username, password):

    with sqlite3.connect(DB_NAME) as conn:

        cursor = conn.cursor()

        cursor.execute(
            """
            SELECT password
            FROM users
            WHERE username=?
            """,
            (username,)
        )

        result = cursor.fetchone()

    if not result:
        return False

    stored_password = result[0]

    return bcrypt.checkpw(
        password.encode(),
        stored_password
    )