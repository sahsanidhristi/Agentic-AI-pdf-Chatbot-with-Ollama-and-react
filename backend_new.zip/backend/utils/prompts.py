# ============================================================
# Prompts — strict to PDF context, no hallucination, no topic mixing
# ============================================================

STRICT_COMMON_RULES = (
    "CRITICAL RULES:\n"
    "1. Use ONLY information from the CONTEXT section below.\n"
    "2. Do NOT use outside knowledge or assumptions.\n"
    "3. Only cover the EXACT topic the user asked about — ignore unrelated content.\n"
    "4. If information is missing from CONTEXT, say: 'Not available in the provided document.'\n"
    "5. Copy terminology EXACTLY as it appears in the CONTEXT.\n"
    "6. Cover EVERY point about the asked topic — do not stop early."
)


def build_prompt(prompt_body: str) -> str:
    return f"{STRICT_COMMON_RULES}\n\n{prompt_body}"


# ------------------------------------------------------------------
# SUMMARY
# FIX: Pinpoint the exact topic from the question first, then summarise
#      ONLY that topic — prevents kernel/OS topic bleed.
# ------------------------------------------------------------------
SUMMARY_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

BEFORE writing anything:
- Extract the EXACT topic from the question (e.g. "types of operating systems", "disk scheduling algorithms").
- That topic is your ONLY filter. Every bullet you write must be about THAT topic.
- If the CONTEXT contains other related topics (e.g. question is about OS types but context also has kernel types), SKIP those other topics entirely.

TASK: Summarize ONLY the exact topic from the question.
- One clear sentence per point.
- Include EVERY point about the asked topic from CONTEXT — do NOT stop early.
- If a point is about a DIFFERENT topic (even a closely related one), EXCLUDE it.

# Summary
- ...
- ...
(MANDATORY: every bullet = asked topic only; list ALL of them)

**Conclusion:** one sentence about the asked topic only.""")


# ------------------------------------------------------------------
# DETAIL / EXPLAIN
# ------------------------------------------------------------------
DETAIL_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

BEFORE writing anything:
- Extract the EXACT topic from the question (e.g. "disk scheduling algorithms", "types of operating systems").
- That topic is your ONLY focus. Do NOT explain other topics even if they appear in the CONTEXT.
- Example: if question = "explain types of OS" and context has both OS types AND kernel types, explain ONLY OS types.

TASK: Explain ONLY the exact topic from the question.
- NO bullet points — write in flowing prose.
- Use ## heading for EACH item/type/algorithm of the asked topic found in CONTEXT.
- 2-3 sentences per section in simple language.
- Cover ALL items/types of the asked topic — do NOT skip any, do NOT stop early.

# [Exact topic from question]

## [Item/Type 1 — exact name from CONTEXT]
2-3 sentences in prose.

## [Item/Type 2 — exact name from CONTEXT]
2-3 sentences in prose.

(MANDATORY: continue for ALL items of the asked topic — stopping early is an error)""")


# ------------------------------------------------------------------
# METHODOLOGY
# ------------------------------------------------------------------
METHODOLOGY_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Extract the methodology/phases/steps for the asked topic from CONTEXT.
- Copy step names EXACTLY from CONTEXT. Do NOT rename them.
- Include EVERY step. Preserve original order.
- 2-4 prose sentences per step — NO bullet points.

# Methodology

## Step 1: [exact name from CONTEXT]
[prose explanation]

## Step 2: [exact name from CONTEXT]
[prose explanation]

(list ALL steps — mandatory)""")


# ------------------------------------------------------------------
# COMPARE
# FIX: Explicit per-cell instruction so entity-B values never bleed
#      into entity-A's column. The model fills one cell at a time.
# ------------------------------------------------------------------
COMPARE_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Create a comparison table using ONLY information from the CONTEXT.
Rules:
- Column 1 = Feature name.
- Column 2 = value for the FIRST entity only.
- Column 3 = value for the SECOND entity only.
- Each cell must contain information for THAT entity only — never mix both entities in one cell.
- Include ALL features mentioned in CONTEXT for these items.
- If a value is absent for one entity, write "—".

| Feature | [Entity A] | [Entity B] |
|---------|-----------|-----------|
| [feature] | [Entity A value only] | [Entity B value only] |
(fill every row — do not stop early)""")


# ------------------------------------------------------------------
# QUIZ
# FIX: Explanation = only why the correct answer is right.
#      Remove "why others are wrong" section entirely.
# ------------------------------------------------------------------
QUIZ_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Generate exactly 3 multiple-choice questions based STRICTLY on the CONTEXT.

**Q1.** [Question from context]
A. [option]
B. [option]
C. [option]
D. [option]
**Answer:** [letter]. [option text]
**Explanation:** [1-2 sentences explaining ONLY why the correct answer is right, using the CONTEXT. Do NOT mention why other options are wrong.]

**Q2.** [Question from context]
A. [option]
B. [option]
C. [option]
D. [option]
**Answer:** [letter]. [option text]
**Explanation:** [1-2 sentences explaining ONLY why the correct answer is right, using the CONTEXT. Do NOT mention why other options are wrong.]

**Q3.** [Question from context]
A. [option]
B. [option]
C. [option]
D. [option]
**Answer:** [letter]. [option text]
**Explanation:** [1-2 sentences explaining ONLY why the correct answer is right, using the CONTEXT. Do NOT mention why other options are wrong.]""")


# ------------------------------------------------------------------
# CITATION
# ------------------------------------------------------------------
CITATION_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Answer in 3-5 sentences using only the CONTEXT.
After each factual claim, add the source phrase in parentheses.

**Answer:** ... *(Source: exact phrase from context)* ...""")


# ------------------------------------------------------------------
# FINANCIAL SUMMARY
# ------------------------------------------------------------------
FINANCIAL_SUMMARY_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Extract ALL financial figures and metrics from the CONTEXT.

# Financial Summary
| Metric | Value |
|--------|-------|
(fill every row — do not stop early)

**Conclusion:** one sentence summary.""")


# ------------------------------------------------------------------
# KPI
# ------------------------------------------------------------------
KPI_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Extract ALL KPIs from the CONTEXT only.

| KPI | Value | Change |
|-----|-------|--------|""")


# ------------------------------------------------------------------
# TREND
# ------------------------------------------------------------------
TREND_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

List ALL trends where values exist in the CONTEXT.

# Trends
- [Metric]: [old] → [new] ([±change])""")


# ------------------------------------------------------------------
# RISK
# ------------------------------------------------------------------
RISK_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

List ALL risks explicitly mentioned in the CONTEXT. 2-3 sentences each.

## Risk 1: [Name from context]
Description. Impact.""")


# ------------------------------------------------------------------
# INVESTOR
# ------------------------------------------------------------------
INVESTOR_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Provide investor insights based strictly on the CONTEXT. No forecasts.

# Investor Insights
- **Strength:** ...
- **Weakness:** ...
- **Key observation:** ...""")


# ------------------------------------------------------------------
# BALANCE SHEET
# ------------------------------------------------------------------
BALANCE_SHEET_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

PART 1 — TABLE: List every balance sheet line item from the CONTEXT.

| Item | Current | Previous | Change |
|------|---------|----------|--------|
(fill every row — do not omit any)

PART 2 — EXPLANATION:
For each item above, write 2-3 sentences: what it represents, what the change means, any notable observation.

## [Item Name]
2-3 sentences.""")


# ------------------------------------------------------------------
# FINANCIAL COMPARE
# ------------------------------------------------------------------
FINANCIAL_COMPARE_PROMPT = build_prompt("""CONTEXT:
{context}

USER QUESTION: {question}

Compare financial metrics from the CONTEXT only.

| Metric | Current | Previous | Change |
|--------|---------|----------|--------|""")
