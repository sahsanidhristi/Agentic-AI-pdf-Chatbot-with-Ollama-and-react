from pypdf import PdfReader


def load_pdf_text(pdf_file):
    reader = PdfReader(pdf_file)
    pages = []

    for i, page in enumerate(reader.pages):
        extracted = page.extract_text()
        if extracted and extracted.strip():
            # Prefix each page so chunks stay page-aware
            pages.append(f"[Page {i + 1}]\n{extracted.strip()}")

    # Double newline between pages → treated as strong separator by splitter
    return "\n\n".join(pages)
