from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_ollama import OllamaEmbeddings


# --------------------------------------------------
# Document Type Detection
# --------------------------------------------------

def detect_financial_report(text):
    financial_keywords = [
        "revenue", "net profit", "balance sheet", "cash flow",
        "ebitda", "assets", "liabilities", "equity",
        "income statement", "financial statements", "annual report",
        "operating income", "shareholders", "expenses",
    ]
    text_lower = text.lower()
    matches = sum(keyword in text_lower for keyword in financial_keywords)
    return matches >= 4


def detect_educational_document(text):
    educational_keywords = [
        "algorithm", "algorithms", "advantages", "disadvantages",
        "steps", "process", "method", "procedure",
        "operating system", "disk scheduling", "page replacement",
        "deadlock", "cpu scheduling", "computer network",
        "database", "definition", "example", "explanation",
    ]
    text_lower = text.lower()
    matches = sum(keyword in text_lower for keyword in educational_keywords)
    return matches >= 4


def detect_research_paper(text):
    research_keywords = [
        "abstract", "methodology", "literature review", "results",
        "discussion", "conclusion", "dataset", "experiment",
        "analysis", "references",
    ]
    text_lower = text.lower()
    matches = sum(keyword in text_lower for keyword in research_keywords)
    return matches >= 4


def detect_document_type(text):
    if detect_financial_report(text):
        return "financial"
    if detect_research_paper(text):
        return "research"
    if detect_educational_document(text):
        return "educational"
    return "general"


# --------------------------------------------------
# Chunking Strategy
# --------------------------------------------------
#
# Key design decisions:
#
# 1. Chunk sizes are LARGER so self-contained items like "Step 3: Do X" land
#    in a single chunk rather than being split across two.
#
# 2. Overlap is ~20% of chunk size — ensures a step straddling a boundary
#    appears in BOTH adjacent chunks, so retrieval never drops it.
#
# 3. min_length filter suppresses pure page-number / header-only chunks.
#
# 4. separators prioritise paragraph and sentence breaks so we don't split
#    mid-sentence. [Page N] markers from pdf_loader act as natural boundaries.
#
# Multi-page PDFs (6-7 pages):
#   A 7-page educational PDF ≈ 7000-10000 chars.
#   With chunk_size=1000 + overlap=200 → ~10-12 chunks per document.
#   TOP_K=15 in main.py retrieves 83-100% of the document for broad questions.
# --------------------------------------------------

CHUNKING_STRATEGIES = {
    "financial": {
        "chunk_size": 700,
        "chunk_overlap": 140,
        "min_length": 80,
    },
    "educational": {
        # "chunk_size": 1000,
        # "chunk_overlap": 200,
        "chunk_size": 1600,
        "chunk_overlap": 300,
        "min_length": 80,
    },
    "research": {
        "chunk_size": 900,
        "chunk_overlap": 180,
        "min_length": 80,
    },
    "general": {
        "chunk_size": 800,
        "chunk_overlap": 160,
        "min_length": 80,
    },
}


# --------------------------------------------------
# Vector Store Creation
# --------------------------------------------------

def create_vector_store(text):
    document_type = detect_document_type(text)
    strategy = CHUNKING_STRATEGIES[document_type]

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=strategy["chunk_size"],
        chunk_overlap=strategy["chunk_overlap"],
        # [Page N] markers inserted by pdf_loader act as top-level separators
        separators=["[Page ", "\n\n\n", "\n\n", "\n", ". ", "! ", "? ", " "],
    )

    chunks = splitter.split_text(text)

    min_len = strategy["min_length"]
    chunks = [c for c in chunks if len(c.strip()) >= min_len]

    metadata = [
        {"document_type": document_type, "chunk_number": i + 1}
        for i in range(len(chunks))
    ]

    embeddings = OllamaEmbeddings(model="nomic-embed-text")

    vector_db = FAISS.from_texts(
        texts=chunks,
        embedding=embeddings,
        metadatas=metadata,
    )

    print(f"[vector_store] type={document_type}  chunks={len(chunks)}  "
          f"chunk_size={strategy['chunk_size']}  overlap={strategy['chunk_overlap']}")

    return vector_db
