import time
import io
from fastapi import FastAPI, UploadFile, File, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import jwt

from auth.auth import create_users_table, register_user, login_user
from utils.pdf_loader import load_pdf_text
from utils.vector_store import create_vector_store
from graph.workflow import build_graph

# ── Init ──────────────────────────────────────────────────────────────────────
create_users_table()
graph = build_graph()

SECRET = "askpdf-secret-key-change-in-prod"

app = FastAPI(title="AskPDF API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── In-memory vector store per user session (keyed by JWT sub) ────────────────
_user_stores: dict = {}
_user_histories: dict = {}


# ── Auth helpers ──────────────────────────────────────────────────────────────

def make_token(username: str) -> str:
    return jwt.encode({"sub": username}, SECRET, algorithm="HS256")


def verify_token(authorization: str = Header(None)) -> str:
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Not authenticated")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        return payload["sub"]
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid token")


# ── Auth endpoints ─────────────────────────────────────────────────────────────

class AuthBody(BaseModel):
    username: str
    password: str


@app.post("/auth/register")
def register(body: AuthBody):
    ok = register_user(body.username, body.password)
    if not ok:
        raise HTTPException(status_code=400, detail="Username already exists")
    return {"message": "Account created"}


@app.post("/auth/login")
def login(body: AuthBody):
    ok = login_user(body.username, body.password)
    if not ok:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = make_token(body.username)
    return {"token": token, "username": body.username}


# ── PDF upload ─────────────────────────────────────────────────────────────────

@app.post("/upload")
async def upload_pdf(
    file: UploadFile = File(...),
    user: str = Depends(verify_token),
):
    if not file.filename.endswith(".pdf"):
        raise HTTPException(status_code=400, detail="Only PDF files supported")

    content = await file.read()
    text = load_pdf_text(io.BytesIO(content))

    if not text.strip():
        raise HTTPException(status_code=400, detail="Could not extract text from PDF")

    _user_stores[user] = create_vector_store(text)
    _user_histories[user] = []

    return {"message": "PDF processed successfully"}


# ── Chat ───────────────────────────────────────────────────────────────────────

class ChatBody(BaseModel):
    question: str


@app.post("/chat")
def chat(body: ChatBody, user: str = Depends(verify_token)):
    if user not in _user_stores:
        raise HTTPException(status_code=400, detail="No PDF loaded")

    vector_db = _user_stores[user]
    history = _user_histories.get(user, [])

    # ── Retrieval strategy ────────────────────────────────────────────────────
    #
    # For 6-7 page PDFs (≈ 7000-10000 chars) with chunk_size=1000:
    #   → ~10-14 chunks total per document.
    #   TOP_K=15 retrieves essentially the full document for broad questions,
    #   ensuring no page is missed.
    #
    # RELEVANCE_THRESHOLD=1.30 (raised from 1.20): nomic-embed-text L2 distances
    #   for same-topic chunks in educational PDFs cluster around 0.9-1.25.
    #   Setting threshold at 1.30 catches all relevant chunks without pulling in
    #   completely unrelated content.
    #
    # Speed note: wider retrieval (NUM_CANDIDATES=30, TOP_K=15) does NOT slow
    #   down the LLM — the bottleneck is token generation, not FAISS search.
    #   FAISS search on 14 chunks takes <5ms regardless of NUM_CANDIDATES.
    #   Speed comes from: (a) smaller prompts (removed verbose rules duplication),
    #   (b) num_predict caps, (c) repeat_penalty stops rambling early.
    #
    # Context budget with num_ctx=8192:
    #   context  : 12 000 chars ≈ 3 000 tokens
    #   prompt   :    ~600 chars ≈   150 tokens
    #   answer   : num_predict  ≈ 2 000 tokens
    #   total    :              ≈ 5 150 tokens → fits in 8 192

    t0 = time.time()

    RELEVANCE_THRESHOLD = 1.30   # raised — catches all same-topic chunks
    NUM_CANDIDATES      = 30     # wide net for FAISS (fast, no LLM cost)
    TOP_K               = 15     # up from 12 — handles full 6-7 page PDFs
    MIN_BEFORE_FALLBACK = 5
    CONTEXT_CHAR_LIMIT  = 12_000 # up from 10000 — covers ~14 chunks @ 800 chars each

    candidates = vector_db.similarity_search_with_score(body.question, k=NUM_CANDIDATES)

    relevant = [(doc, score) for doc, score in candidates if score <= RELEVANCE_THRESHOLD]

    # Fallback: strict filter left too few results → use top-K by score
    if len(relevant) < MIN_BEFORE_FALLBACK:
        relevant = sorted(candidates, key=lambda x: x[1])[:TOP_K]

    relevant.sort(key=lambda x: x[1])
    top_docs = [doc for doc, _ in relevant[:TOP_K]]

    context = "\n\n".join(d.page_content for d in top_docs)[:CONTEXT_CHAR_LIMIT]
    retrieval_ms = round((time.time() - t0) * 1000)

    state = {
        "question": body.question,
        "context": context,
        "answer": "",
        "agent_type": "",
        "chat_history": history,
        "citations": [],
        "intermediate_outputs": [],
    }

    t1 = time.time()
    result = graph.invoke(state)
    llm_ms = round((time.time() - t1) * 1000)

    answer = result["answer"]

    history.append({"role": "user", "content": body.question})
    history.append({"role": "assistant", "content": answer})
    _user_histories[user] = history

    return {
        "answer": answer,
        "agent_type": result.get("agent_type", ""),
        "retrieval_ms": retrieval_ms,
        "llm_ms": llm_ms,
    }


# ── Session helpers ────────────────────────────────────────────────────────────

@app.post("/new-chat")
def new_chat(user: str = Depends(verify_token)):
    _user_stores.pop(user, None)
    _user_histories.pop(user, None)
    return {"message": "Session cleared"}


@app.get("/history")
def get_history(user: str = Depends(verify_token)):
    return {"history": _user_histories.get(user, [])}


@app.get("/pdf-status")
def pdf_status(user: str = Depends(verify_token)):
    return {"ready": user in _user_stores}
